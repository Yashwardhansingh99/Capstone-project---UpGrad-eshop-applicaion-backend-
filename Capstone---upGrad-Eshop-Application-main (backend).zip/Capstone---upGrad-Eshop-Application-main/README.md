# upGrad-Eshop-Backend
upGrad Eshop application UI using React to interact with and store the data in the MongoDB database
